import SwiftUI
import Cocoa

@main
struct TextRecognitionApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(appDelegate)
        }
    }
}

class AppDelegate: NSObject, NSApplicationDelegate, ObservableObject {
    @Published var lastAppName: String = ""
    @Published var capturedText: String = ""
    @Published var highlightedText: String = "" // New feature: highlighted text
    
    private var sentenceBuffer: String = ""
    
    func applicationDidFinishLaunching(_ notification: Notification) {
        // Start observing for active application changes
        observeApplicationFocus()
        
        // Start listening for key presses
        listenForKeyPresses()
    }
    
    private func observeApplicationFocus() {
        NSWorkspace.shared.notificationCenter.addObserver(
            self,
            selector: #selector(applicationDidActivate(notification:)),
            name: NSWorkspace.didActivateApplicationNotification,
            object: nil
        )
    }
    
    @objc private func applicationDidActivate(notification: Notification) {
        guard let app = notification.userInfo?[NSWorkspace.applicationUserInfoKey] as? NSRunningApplication else {
            return
        }
        let appName = app.localizedName ?? "Unknown App"
        
        // Only update when the application name changes
        if appName != lastAppName {
            lastAppName = appName
            sentenceBuffer = "" // Reset the buffer for new app
            print("Switched to application: \(appName)")
            DispatchQueue.main.async {
                self.capturedText = "" // Reset the UI text for new app
            }
        }
    }
    
    private func listenForKeyPresses() {
        NSEvent.addGlobalMonitorForEvents(matching: .keyDown) { event in
            if let characters = event.characters, !characters.isEmpty {
                self.handleKeyPress(characters)
            }
        }
    }
    
    private func handleKeyPress(_ characters: String) {
        // Append characters to buffer until a sentence is completed
        sentenceBuffer += characters
        
        // Detect sentence completion (space, period, or Enter)
        if characters == " " || characters == "." || characters == "\n" {
            DispatchQueue.main.async {
                self.capturedText = self.sentenceBuffer
            }
//            sentenceBuffer = "" // Reset buffer for the next sentence
        } else {
            // Update captured text in real-time
            DispatchQueue.main.async {
                self.capturedText = self.sentenceBuffer
            }
        }
        
        // For each character press, update the buffer and app name
        print("Key Pressed: \(characters)")
        print("In Application: \(self.lastAppName)")
    }
    
    // New feature: Function to highlight or manipulate captured text
    func highlightCapturedText() {
        highlightedText = "★ " + capturedText + " ★" // Simple highlighting
        print("Highlighted Text: \(highlightedText)")
    }
    
    // Functionality to replace text in the target app (stub, depends on accessibility APIs)
    func replaceTextInTargetApp(with newText: String) {
        print("Replacing text in \(lastAppName) with: \(newText)")
    }
}

struct ContentView: View {
    @EnvironmentObject var appDelegate: AppDelegate
    
    var body: some View {
        VStack(alignment: .leading) {
            Text("Current Application: \(appDelegate.lastAppName)")
                .font(.title2)
                .padding(.bottom)
            
            Text("Captured Text:")
                .font(.headline)
            
            Text(appDelegate.capturedText.isEmpty ? "No text captured yet" : appDelegate.capturedText)
                .padding()
                .frame(maxWidth: .infinity, minHeight: 100)
                .background(Color.gray.opacity(0.2))
                .cornerRadius(8)
            
            // New feature: Display highlighted text
            if !appDelegate.highlightedText.isEmpty {
                Text("Highlighted Text: \(appDelegate.highlightedText)")
                    .padding()
                    .foregroundColor(.red)
                    .background(Color.yellow.opacity(0.3))
                    .cornerRadius(8)
            }
            
            HStack {
                Button(action: {
                    appDelegate.highlightCapturedText() // New feature to highlight text
                }) {
                    Text("Highlight Text")
                        .padding()
                        .background(Color.green)
                        .foregroundColor(.white)
                        .cornerRadius(8)
                }

                Button(action: {
                    appDelegate.replaceTextInTargetApp(with: "New Replaced Text")
                }) {
                    Text("Replace Text in App")
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(8)
                }
            }
        }
        .padding()
        .frame(width: 400, height: 400)
    }
}
