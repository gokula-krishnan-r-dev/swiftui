//
//  File.swift
//  grammarly-suggest
//
//  Created by Gokula Krishnan R on 22/09/24.
//

import Foundation
import Quartz

func keyString(for keyCode: Int64, flags: UInt64) -> String? {
    // Check for modifier keys (e.g., Shift, Command, Option)
    let shiftPressed = flags & CGEventFlags.maskShift.rawValue != 0
    let optionPressed = flags & CGEventFlags.maskAlternate.rawValue != 0
    let commandPressed = flags & CGEventFlags.maskCommand.rawValue != 0
    let controlPressed = flags & CGEventFlags.maskControl.rawValue != 0
    
    // Key map with alphabet and numbers, with dynamic handling of shift
    let keyMap: [Int64: String] = [
        0: shiftPressed ? "A" : "a", 1: shiftPressed ? "S" : "s",
        2: shiftPressed ? "D" : "d", 3: shiftPressed ? "F" : "f",
        4: shiftPressed ? "H" : "h", 5: shiftPressed ? "G" : "g",
        6: shiftPressed ? "Z" : "z", 7: shiftPressed ? "X" : "x",
        8: shiftPressed ? "C" : "c", 9: shiftPressed ? "V" : "v",
        11: shiftPressed ? "B" : "b", 12: shiftPressed ? "Q" : "q",
        13: shiftPressed ? "W" : "w", 14: shiftPressed ? "E" : "e",
        15: shiftPressed ? "R" : "r", 16: shiftPressed ? "Y" : "y",
        17: shiftPressed ? "T" : "t", 18: shiftPressed ? "1" : "1",
        19: shiftPressed ? "2" : "2", 20: shiftPressed ? "3" : "3",
        21: shiftPressed ? "4" : "4", 22: shiftPressed ? "6" : "6",
        23: shiftPressed ? "5" : "5", 24: shiftPressed ? "=" : "-",
        25: shiftPressed ? "9" : "9", 26: shiftPressed ? "7" : "7",
        27: shiftPressed ? "-" : "=", 28: shiftPressed ? "8" : "8",
        29: shiftPressed ? "0" : "0", 30: shiftPressed ? "]" : "[",
        31: shiftPressed ? "O" : "o", 32: shiftPressed ? "U" : "u",
        33: shiftPressed ? "[" : "]", 34: shiftPressed ? "I" : "i",
        35: shiftPressed ? "P" : "p", 37: shiftPressed ? "L" : "l",
        38: shiftPressed ? "J" : "j", 39: shiftPressed ? "\"" : "'",
        40: shiftPressed ? "K" : "k", 41: shiftPressed ? ":" : ";",
        42: shiftPressed ? "\\" : "\\", 43: shiftPressed ? "," : ",",
        44: shiftPressed ? "/" : "/", 45: shiftPressed ? "N" : "n",
        46: shiftPressed ? "M" : "m", 47: shiftPressed ? "." : ".",
        49: shiftPressed ? "\n" : "\n",
        50: shiftPressed ? "`" : "`",
        
        // Function and Special Keys
        51: "Delete", 53: "Escape",
        123: "Left Arrow", 124: "Right Arrow",
        125: "Down Arrow", 126: "Up Arrow",
        36: "Return", 48: "Tab",
        122: "F1", 120: "F2", 99: "F3", 118: "F4", 96: "F5",
        97: "F6", 98: "F7", 100: "F8", 101: "F9", 109: "F10",
        103: "F11", 111: "F12"
    ]
    
    // Modifier keys
    if commandPressed {
        return "⌘"
    } else if optionPressed {
        return "⌥"
    } else if controlPressed {
        return "⌃"
    } else {
        return keyMap[keyCode]
    }
}


import Vision
import Cocoa

func performTextRecognition(on image: NSImage) {
    let requestHandler = VNImageRequestHandler(cgImage: image.cgImage(forProposedRect: nil, context: nil, hints: nil)!, options: [:])
    
    let textRecognitionRequest = VNRecognizeTextRequest { (request, error) in
        guard let observations = request.results as? [VNRecognizedTextObservation] else { return }
        
        let recognizedStrings = observations.compactMap { observation in
            return observation.topCandidates(1).first?.string
        }
        
        // Print recognized text
        for text in recognizedStrings {
            print("Recognized: \(text)")
        }
    }
    
    do {
        try requestHandler.perform([textRecognitionRequest])
    } catch {
        print("Error performing text recognition: \(error.localizedDescription)")
    }
}
