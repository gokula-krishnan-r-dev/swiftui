import SwiftUI

struct Sidebar: View {
    
    @State var backgroundImage: String?
    @State var launchGame = false
    
    var body: some View {
        ScrollView { // Wrap the content in a ScrollView
            VStack {
                HeroView()
                    .overlay(
                        HStack {
                            Logo()
                            Spacer()
                        }
                        .padding(.top, 30)
                        .padding(.leading, 40)
                        , alignment: .topLeading
                    )
                
                
                HomeView()
                    .padding()
            }
        }
    }
}

struct Logo: View {
    // State variable to hold the dynamic logo URL
    @State private var logoURL: URL? = URL(string: "https://zynoflixott.com/_next/image?url=%2Flogo%2Flogo.png&w=384&q=75")

    var body: some View {
        HStack {
            // AsyncImage with dynamic logo URL
            if let logoURL = logoURL {
                AsyncImage(url: logoURL) { phase in
                    switch phase {
                    case .empty:
                        ProgressView()
                    case .failure:
                        Image(systemName: "exclamationmark.icloud")
                    case .success(let image):
                        image.resizable()
                    @unknown default:
                        Image(systemName: "exclamationmark.icloud")
                    }
                }
                .frame(width: 200, height: 120) // Adjust the frame size as needed
            }
        }
    }
}

#Preview {
    ContentView()
}
