//
//  VideoCardView.swift
//  zynoflixott
//
//  Created by Gokula Krishnan R on 24/08/24.
//

import SwiftUI


struct VideoCardView: View {
    let video: Video
    let isFocused: Bool
    
    var body: some View {
        ZStack(alignment: .bottom) {
            AsyncImage(url: URL(string: video.thumbnail)) { image in
                image
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .cornerRadius(15)
                    .frame(width: 390, height: 550)
                    .cornerRadius(20)
            } placeholder: {
                ProgressView()
            }
            .overlay(
                Color.black.opacity(0.4)
                    .cornerRadius(15)
            )
            
            Text(video.title)
                .foregroundColor(.white)
                .font(.system(size: 24, weight: .bold))
                .lineLimit(2)
                .padding()
        }
        .padding(.vertical, 60)
        .frame(width: 390, height: 550)
        .scaleEffect(isFocused ? 1.1 : 1.0)  // Scale up the focused item
        .animation(.easeInOut, value: isFocused)
    }
}


