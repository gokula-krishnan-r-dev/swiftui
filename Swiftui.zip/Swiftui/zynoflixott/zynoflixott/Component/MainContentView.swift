//
//  MainContentView.swift
//  zynoflixott
//
//  Created by Gokula Krishnan R on 20/08/24.
//

import SwiftUI

struct MainContentView: View {
    @StateObject private var authNetworkManager = AuthNetworkManager()

    var body: some View {
        VStack{
            
            if (authNetworkManager.isAuth){
                AuthLoginView()
                    .padding()
            } else {
                Sidebar()
            }
        }

        
    }
}

