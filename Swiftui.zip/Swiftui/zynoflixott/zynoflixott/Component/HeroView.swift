import SwiftUI

struct HeroView: View {
    // The state to manage focus
    @FocusState private var isHeroViewFocused: Bool
    @State private var currentIndex = 0 // To track the current page index
    @StateObject private var viewModel = VideoViewModel()
    @State private var showSuccessAlert = false
    @State private var focusedVideoID: String?
    @State  var selectedVideo: Video?
    @State private var isVideoPlaying: Bool = false
    
    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack() {
                ForEach(viewModel.videos) { video in
                    BannerCardCompView(video: video, isFocused: focusedVideoID == video.id)
                        .focusable(true)
                        .focusable(onFocusChange: { isFocused in
                            if isFocused {
                                focusedVideoID = video.id
                            }
                        })
                        .onTapGesture {
                            selectedVideo = video
                            isVideoPlaying = true
                        }
                }
            }
            .frame(width:.infinity ,height: 760)
            .ignoresSafeArea(.all)
        }
    }
}

//
//  VideoCardView.swift
//  zynoflixott
//
//  Created by Gokula Krishnan R on 24/08/24.
//

import SwiftUI


struct BannerCardCompView: View {
    let video: Video
    let isFocused: Bool
    
    var body: some View {
        ZStack(alignment: .bottomLeading) {
            // Background video player view
            BackgroundVideoPlayerView(videoURL: URL(string: video.previewVideo)!)
                .disabled(true)
                .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
                .clipped()

            
            // Dark overlay for text contrast
            LinearGradient(gradient: Gradient(colors: [Color.black.opacity(0.4), Color.black.opacity(0.2)]), startPoint: .bottom, endPoint: .center)
               
            
            // Video details text
            VStack(alignment: .leading, spacing: 8) {
                Text(video.title)
                    .foregroundColor(.white)
                    .font(.system(size: 34, weight: .bold))
                    .lineLimit(2)
                
                
                Text("English | Experimental_short")
                    .foregroundColor(.white.opacity(0.8))
                    .font(.system(size: 24, weight: .regular))
                
                
                
            }
            .padding(.top , -400)
            .padding(.horizontal , 50)

        }
        .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        .animation(.easeInOut, value: isFocused)
    }
}



#Preview {
    ContentView()
}
