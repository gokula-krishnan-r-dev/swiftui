import SwiftUI
import AVKit

struct BackgroundVideoPlayerView: View {
    @State private var player: AVPlayer? = nil

    var videoURL: URL

    var body: some View {
        ZStack {
            Color.black.edgesIgnoringSafeArea(.all)  // Set the background color to black

            if let player = player {
                VideoPlayer(player: player)
                    .onAppear {
                        player.isMuted = true // Mute the audio
                        player.play() // Start playback
                        setupLooping(player: player) // Set up looping for the video
                    }
                    .onDisappear {
                        player.pause() // Pause playback when the view disappears
                    }
                    .edgesIgnoringSafeArea(.all)
                    .ignoresSafeArea()// Make the video player full screen
            } else {
                Text("Loading video...")
                    .foregroundColor(.white)
            }
        }
        .onAppear {
            player = AVPlayer(url: videoURL)
        }
        .onDisappear {
            player?.pause()
            player = nil
        }
    }

    private func setupLooping(player: AVPlayer) {
        // Set up the video to loop indefinitely
        NotificationCenter.default.addObserver(forName: .AVPlayerItemDidPlayToEndTime, object: player.currentItem, queue: .main) { _ in
            player.seek(to: .zero)
            player.play()
        }
    }
}

#Preview {
    ContentView()
}
