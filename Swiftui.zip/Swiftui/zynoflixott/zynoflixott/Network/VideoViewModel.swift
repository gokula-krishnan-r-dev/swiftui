//
//  VideoViewModel.swift
//  zynoflixott
//
//  Created by Gokula Krishnan R on 20/08/24.
//

import Foundation
import SwiftUI
import Combine
import Foundation



struct Video: Codable, Identifiable {
    let id: String
    let title: String
    let description: String
    let thumbnail: String
    let previewVideo: String
    let originalVideo: String
    let duration: String
    let certification: String
    let language: [String]
    let category: [String]
    let likes: Int
    let views: Int
    
    enum CodingKeys: String, CodingKey {
        case id = "_id"
        case title
        case description
        case thumbnail
        case previewVideo = "preview_video"
        case originalVideo = "original_video"
        case duration
        case certification
        case language
        case category
        case likes
        case views
    }
}

struct VideoResponse: Codable {
    let videos: [Video]
}



class VideoViewModel: ObservableObject {
    @Published var videos: [Video] = []
    private var cancellable: AnyCancellable?
    
    init() {
        fetchVideos()
    }
    
    func fetchVideos() {
        guard let url = URL(string: "https://api.zynoflixott.com/api/videos") else { return }
        
        cancellable = URLSession.shared.dataTaskPublisher(for: url)
            .map { $0.data }
            .decode(type: VideoResponse.self, decoder: JSONDecoder())
            .replaceError(with: VideoResponse(videos: []))
            .receive(on: DispatchQueue.main)
            .sink { [weak self] in
                self?.videos = $0.videos
            }
    }
}
