import SwiftUI
import Combine

// Define TvOs struct for the response
struct TvOs: Codable {
    let _id: String
    let accessToken: String
    let username: String
    let role: String
    let success: Bool
    let otp: String
    let uuid: String
    let userId: String
}

// Define TvOsAuthResponse to handle both array and single object responses
struct TvOsAuthResponse: Codable {
    let tvOs: [TvOs]
    
    // Custom initializer to handle dynamic response
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        if let tvOsArray = try? container.decode([TvOs].self, forKey: .tvOs) {
            self.tvOs = tvOsArray
        } else if let tvOsObject = try? container.decode(TvOs.self, forKey: .tvOs) {
            self.tvOs = [tvOsObject]
        } else {
            throw DecodingError.typeMismatch([TvOs].self, DecodingError.Context(codingPath: decoder.codingPath, debugDescription: "Expected to decode an array or a dictionary."))
        }
    }
}

class AuthNetworkManager: ObservableObject {
    @Published var tvOs: TvOs?
    @Published var errorMessage: String?
    @Published var requestStatus: String = "wait"
    @Published var showSuccessAlert: Bool = false
    @Published var isAuth: Bool = false // Property to track authentication status
    
    private var cancellables = Set<AnyCancellable>()
    private var fetchTimer: AnyCancellable?

    init() {
        print("AuthNetworkManager initialized")
        startOtpFetchTimer()
    }
    
    
    // Start a timer to verify OTP every 20 seconds
    func startOtpFetchTimer() {
        fetchTimer = Timer.publish(every: 20.0, on: .main, in: .common)
            .autoconnect()
            .sink { [weak self] _ in
                self?.verifyOtp(self?.tvOs?.uuid ?? "")
            }
    }

    // Function to fetch OTP
    func fetchOtp() {
        guard let url = URL(string: "http://localhost:8080/api/auth/tvos/otp") else {
            print("Invalid URL")
            requestStatus = "Invalid URL"
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        requestStatus = "Requesting..."
        print("Requesting OTP from server...")
        
        URLSession.shared.dataTaskPublisher(for: request)
            .tryMap { output in
                guard let response = output.response as? HTTPURLResponse else {
                    print("No response received from server")
                    self.requestStatus = "No response"
                    throw URLError(.badServerResponse)
                }
                print("Response status code: \(response.statusCode)")
                
                if response.statusCode == 201 {
                    print(output.data)
                    return output.data
                } else {
                    print("Server responded with status code: \(response.statusCode)")
                    self.requestStatus = "Server error \(response.statusCode)"
                    throw URLError(.badServerResponse)
                }
            }
            .decode(type: TvOsAuthResponse.self, decoder: JSONDecoder())
            .receive(on: DispatchQueue.main)
            .sink(receiveCompletion: { completion in
                switch completion {
                case .failure(let error):
                    self.errorMessage = "Failed to fetch OTP: \(error)"
                    self.requestStatus = "Failed"
                    print(self.errorMessage ?? "Unknown error")
                case .finished:
                    print("Request completed successfully")
                }
            }, receiveValue: { [weak self] response in
                if let tvOsResponse = response.tvOs.first { // Accessing the first element in the array
                    self?.tvOs = tvOsResponse
                    print("OTP fetched successfully: \(tvOsResponse.otp)")
                    self?.verifyOtp(tvOsResponse.uuid) // Verify OTP after fetching
                    self?.startOtpFetchTimer() // Start the timer to verify OTP periodically
                }
            })
            .store(in: &cancellables)
    }
    
    // Function to verify OTP
    func verifyOtp(_ uuid: String) {
        guard let url = URL(string: "http://localhost:8080/api/auth/verify/\(uuid)") else {
            print("Invalid URL")
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        
        URLSession.shared.dataTaskPublisher(for: request)
            .tryMap { output in
                guard let response = output.response as? HTTPURLResponse else {
                    print("No response received from server")
                    throw URLError(.badServerResponse)
                }
                print("Response status code: \(response.statusCode)")
                
                if response.statusCode == 200 {
                    return output.data
                } else {
                    print("Server responded with status code: \(response.statusCode)")
                    throw URLError(.badServerResponse)
                }
            }
            .decode(type: TvOsAuthResponse.self, decoder: JSONDecoder())
            .receive(on: DispatchQueue.main)
            .sink(receiveCompletion: { completion in
                switch completion {
                case .failure(let error):
                    print("Failed to verify OTP: \(error)")
                case .finished:
                    print("OTP verification completed successfully")
                }
            }, receiveValue: { [weak self] response in
                if let tvOsResponse = response.tvOs.first, tvOsResponse.success == true {
                    self?.requestStatus = "Success"
                    self?.saveToLocalStorage(accessToken: tvOsResponse.accessToken, userId: tvOsResponse.username)
                    self?.showSuccessAlert = true // Trigger success alert
                    print("AccessToken and UserId saved successfully")
                } else {
                    print("OTP verification failed")
                }
            })
            .store(in: &cancellables)
    }
    
    // Function to save data to local storage
    func saveToLocalStorage(accessToken: String, userId: String) {
        UserDefaults.standard.set(accessToken, forKey: "accessToken")
        UserDefaults.standard.set(userId, forKey: "userId")
        self.isAuth = !accessToken.isEmpty // Set isAuth based on whether accessToken is empty or not
    }
}
