//
//  VideoNetworkLikeModel.swift
//  zynoflixott
//
//  Created by Gokula Krishnan R on 27/08/24.
//

import Foundation
import Combine

struct LikeResponse: Codable {
    let like: [Like]
}

struct Like: Codable {
    let _id: String
    let video_id: String
    let user_id: [String]
    let createdAt: String
    let updatedAt: String
}

struct LikeData: Codable {
    let video_id: String
    let user_id: [String]
}

class NetworkManager: ObservableObject {
    @Published var likeCount: Int = 0
    @Published var isAuth: Bool = false
    
    private var cancellable: AnyCancellable?
    
    private var accessToken: String? {
        UserDefaults.standard.string(forKey: "accessToken")
    }
    
    private var userId: String? {
        UserDefaults.standard.string(forKey: "userId")
    }
    
    // Save access token and user ID to UserDefaults
    func saveToLocalStorage(accessToken: String, userId: String) {
        UserDefaults.standard.set(accessToken, forKey: "accessToken")
        UserDefaults.standard.set(userId, forKey: "userId")
        self.isAuth = !accessToken.isEmpty // Set isAuth based on whether accessToken is empty or not
    }
    
    // Perform a GET request to fetch the like count
    func getLikeCount(videoID: String) {
        guard let url = URL(string: "http://localhost:8080/api/video/like/\(videoID)"),
              let token = accessToken else {
            return
        }
        
        var request = URLRequest(url: url)
        request.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        
        cancellable = URLSession.shared.dataTaskPublisher(for: request)
            .map { $0.data }
            .decode(type: LikeResponse.self, decoder: JSONDecoder())
            .receive(on: DispatchQueue.main)
            .sink(receiveCompletion: { _ in }, receiveValue: { [weak self] response in
                self?.likeCount = response.like.count
            })
    }
    
    // Perform a POST request to like the video
    func postLike(videoID: String) {
        guard let url = URL(string: "http://localhost:8080/api/video/like/\(videoID)"),
              let token = accessToken,
              let userId = userId else {
            return
        }
   
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        
        let likeData = LikeData(video_id: videoID, user_id: [userId])
        
        do {
            print("working")
            request.httpBody = try JSONEncoder().encode(likeData)
        } catch {
            print("Failed to encode like data: \(error)")
            return
        }
        
        cancellable = URLSession.shared.dataTaskPublisher(for: request)
            .map { $0.data }
            .decode(type: LikeResponse.self, decoder: JSONDecoder())
            .receive(on: DispatchQueue.main)
            .sink(receiveCompletion: { _ in }, receiveValue: { [weak self] response in
                self?.likeCount = response.like.count
            })
    }
}
