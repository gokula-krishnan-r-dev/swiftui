//
//  zynoflixottApp.swift
//  zynoflixott
//
//  Created by Gokula Krishnan R on 20/08/24.
//

import SwiftUI

@main
struct zynoflixottApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
