import SwiftUI
import AVFoundation
import AVKit
import MediaPlayer

struct PreviewView: View {
    // Step 1: Declare a FocusState property
    @FocusState private var watchNowButtonFocused: Bool
    @State private var isVideoPlaying: Bool = false
    @Binding var selectVideo: Video?
    @StateObject private var networkManager = NetworkManager()
    let videoID = "66cb1806bc373fb12b33dabf" // Example video ID
    var body: some View {
        ZStack(alignment: .topLeading) {
            // Background Video
            BackgroundVideoPlayerView(videoURL: URL(string: selectVideo?.previewVideo ?? "")!)
                .disabled(true)

            // Gradient Overlay for better text readability
            LinearGradient(gradient: Gradient(colors: [Color.black.opacity(0.4), Color.black.opacity(0.3)]),
                           startPoint: .topLeading,
                           endPoint: .bottomTrailing)
                .edgesIgnoringSafeArea(.all)
                
            // Main Content
            VStack(spacing: 20) {
                HStack(alignment: .bottom) {
                    // Movie Poster
                    AsyncImage(url: URL(string: selectVideo?.thumbnail ?? "")) { image in
                        image
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .cornerRadius(15)
                            .frame(width: 390, height: 550)
                            .cornerRadius(20)
                    } placeholder: {
                        ProgressView()
                    }
                    
                    // Movie Details
                    VStack(alignment: .leading, spacing: 10) {
                        HStack {
                            ForEach(selectVideo?.category ?? ["romatic"], id: \.self) { category in
                                            TagView(tag: category)
                                        }
                                    }
                        
                        // Movie Title and Tags
                        Text(selectVideo?.title ?? "video title")
                            .font(.headline)
                            .fontWeight(.bold)
                            .foregroundColor(.white)
                        
                        // Movie Description
                        Text(selectVideo?.description ?? "video des")
                            .font(.body)
                            .foregroundColor(.white)
                            .lineLimit(4)
                            .padding(.top, 5)
                        HStack(spacing: 30){
                            // Watch Now Button
                            Button(action: {
                                // Action for "Watch Now"
                                isVideoPlaying.toggle()
                            }) {
                                Text("Watch Now")
                                    .font(.caption)
                            }
                            .focused($watchNowButtonFocused) // Step 2: Attach the FocusState to the button
                            Button(action: {
                                    
                                            // Send POST request to like the video
                                            networkManager.postLike(videoID: videoID)
                                            
                                            // Fetch the updated like count
                                            networkManager.getLikeCount(videoID: videoID)
                                        }) {
                                            Text("Likes: \(networkManager.likeCount)")
                                                            .font(.headline)
                                               
                                        }
                            
                            Button(action: {
                                // Action for "Watch Now"
                                isVideoPlaying.toggle()
                            }) {
                                Text("Comment")
                                    .font(.caption)
                            }
                        }
                    }
                    .padding(.leading, 20)
                    .padding(.top, 180)
                    
                    Spacer()
                    
                    // Movie Rating and Cast Info
                    VStack(alignment: .leading, spacing: 10) {
                        Text("\(String(describing: selectVideo?.likes))")
                            .font(.largeTitle)
                            .fontWeight(.bold)
                            .foregroundColor(Color.green)
                        
                        Text("Likes")
                            .font(.caption)
                            .foregroundColor(.white)
                        
                        Spacer()
                        
                        VStack(alignment: .leading, spacing: 5) {
                            Text("DIRECTOR")
                                .font(.caption)
                                .fontWeight(.bold)
                                .foregroundColor(.white)
                            
                            Text("Christopher Nolan")
                                .font(.caption)
                                .foregroundColor(.white)
                            
                            Text("CAST")
                                .font(.caption)
                                .fontWeight(.bold)
                                .foregroundColor(.white)
                                .padding(.top, 5)
                            
                            Text("Matthew McConaughey")
                                .font(.caption)
                                .foregroundColor(.white)
                            Text("Anne Hathaway")
                                .font(.caption)
                                .foregroundColor(.white)
                            Text("Jessica Chastain")
                                .font(.caption)
                                .foregroundColor(.white)
                        }
                    }
                    .padding(.leading, 50)
                    .padding(.top, 50)
                }
            }
            .padding()
            .onAppear {
                // Step 3: Set the initial focus to the "Watch Now" button
                watchNowButtonFocused = true
            }
            .fullScreenCover(isPresented: $isVideoPlaying) {
                VideoPlayerView(selectVideo: $selectVideo, videoURL: URL(string: selectVideo?.originalVideo ?? "https://etubees.s3.us-east-1.amazonaws.com/zynoflix-ott/1724126977725-videoplayback.mp4")!)
            }
            .onAppear {
                        // Fetch the initial like count when the view appears
                        networkManager.getLikeCount(videoID: videoID)
                    }
        }
    }
}



struct TagView: View {
    let tag: String
    
    var body: some View {
        Text(tag)
            .font(.caption)
            .foregroundColor(.white)
            .padding(.horizontal, 20)
            .padding(.vertical, 10)
            .background(Color.gray.opacity(0.9))
            .cornerRadius(50)
    }
}





#Preview{
    ContentView()
}
