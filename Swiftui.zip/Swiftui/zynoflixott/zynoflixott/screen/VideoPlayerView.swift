import SwiftUI
import AVKit

struct VideoById: Identifiable {
    let id: String
    let title: String
    let thumbnail: String
    let url: String
}

struct VideoPlayerView: View {
    @Environment(\.presentationMode) var presentationMode
    @State private var player: AVPlayer? = nil
    @State private var isControlsVisible: Bool = true
    @State private var hideControlsWorkItem: DispatchWorkItem?
    @State private var isPlaying: Bool = false
    @Binding var selectVideo: Video?
    var videoURL: URL

    var body: some View {
        ZStack(alignment: .topLeading) {
            Color.black.edgesIgnoringSafeArea(.all)  // Set the background color to black
            
            if let player = player {
                VideoPlayer(player: player)
                    .onAppear {
                        player.play()
                        isPlaying = true
                        scheduleHideControls()
                        observePlayerEnd()
                    }
                    .onDisappear {
                        player.pause()
                    }
                    .edgesIgnoringSafeArea(.all)  // Make the video player full screen
                    .contentShape(Rectangle()) // Make the entire area tappable
                    .onTapGesture {
                        toggleControlsVisibility()
                    }
                    .overlay(
                        Group {
                            VStack {
                                HStack {
                                    if isControlsVisible {
                                        Text(selectVideo?.title ?? "")
                                            .font(.headline)
                                            .foregroundColor(.white)
                                    }
                                    Spacer()
                                    Logo()
                                        .opacity(0.6)
                                }
                                Spacer()
                            }
                        }
                    )
            } else {
                Text("Loading video...")
                    .foregroundColor(.white)
            }
        }
        .onAppear {
            player = AVPlayer(url: videoURL)
        }
        .onDisappear {
            player?.pause()
            player = nil
        }
    }
    
    private func toggleControlsVisibility() {
        if isControlsVisible {
            hideControls()
        } else {
            showControls()
        }
    }
    
    private func showControls() {
        isControlsVisible = true
        scheduleHideControls()
    }
    
    private func hideControls() {
        isControlsVisible = false
        hideControlsWorkItem?.cancel()
    }
    
    private func scheduleHideControls() {
        hideControlsWorkItem?.cancel()
        
        let workItem = DispatchWorkItem {
            withAnimation {
                isControlsVisible = false
            }
        }
        
        hideControlsWorkItem = workItem
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 3, execute: workItem)
    }
    
    private func observePlayerEnd() {
        NotificationCenter.default.addObserver(
            forName: .AVPlayerItemDidPlayToEndTime,
            object: player?.currentItem,
            queue: .main
        ) { _ in
            presentationMode.wrappedValue.dismiss()
        }
    }
    
    private func togglePlayPause() {
        if isPlaying {
            player?.pause()
        } else {
            player?.play()
        }
        isPlaying.toggle()
    }
    
    private func currentTime() -> String {
        guard let currentTime = player?.currentTime() else { return "00:00" }
        let totalSeconds = CMTimeGetSeconds(currentTime)
        return formatTime(seconds: totalSeconds)
    }
    
    private func duration() -> String {
        guard let duration = player?.currentItem?.duration else { return "00:00" }
        let totalSeconds = CMTimeGetSeconds(duration)
        return formatTime(seconds: totalSeconds)
    }
    
    private func formatTime(seconds: Double) -> String {
        let minutes = Int(seconds) / 60
        let seconds = Int(seconds) % 60
        return String(format: "%02d:%02d", minutes, seconds)
    }
}

