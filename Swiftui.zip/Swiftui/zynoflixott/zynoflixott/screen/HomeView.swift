import SwiftUI

struct HomeView: View {
    @StateObject private var viewModel = VideoViewModel()
    @State private var showSuccessAlert = false
    @State private var focusedVideoID: String?
    @State  var selectedVideo: Video?
    @State private var isVideoPlaying: Bool = false

    var body: some View {
        ZStack(alignment: .top) {
            Color.black.edgesIgnoringSafeArea(.all)  // Set the background color to black
            VStack(alignment: .leading, spacing: 20) {
                Text("Featured Content")
                    .font(.system(size: 50, weight: .bold))
                    .foregroundColor(.white)
                    .padding(.leading, 50)
                    .padding(.top, 60)
                
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 20) {
                        ForEach(viewModel.videos) { video in
                            VideoCardView(video: video, isFocused: focusedVideoID == video.id)
                                .focusable(true)
                                .focusable(onFocusChange: { isFocused in
                                    if isFocused {
                                        focusedVideoID = video.id
                                    }
                                })
                                .onTapGesture {
                                    selectedVideo = video
                                    isVideoPlaying = true
                                }
                        }
                    }
                    .frame(height: 650)
                }
                Spacer()
            }
            .fullScreenCover(item: $selectedVideo) { video in
                PreviewView(selectVideo: $selectedVideo)
               
            }
        }
    }
}

#Preview {
    HomeView()
}

