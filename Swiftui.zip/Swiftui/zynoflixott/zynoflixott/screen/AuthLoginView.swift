import SwiftUI

struct AuthLoginView: View {
    @StateObject private var authNetworkManager = AuthNetworkManager()
    @State private var showOTPInput = false
    @State private var showSuccessScreen = false

    var body: some View {
        VStack(spacing: 20) {
            if (!showOTPInput && !showSuccessScreen){
                loginMessageScreen()
            }
            // OTP Input Screen
            if (!showSuccessScreen && showOTPInput) {
                otpInputScreen()
            }

            // Success Screen
            if showSuccessScreen {
                successScreen()

            }
        }
        .padding()
        .onChange(of: authNetworkManager.tvOs?.otp) { newValue in
            if newValue != nil {
                showOTPInput = true
            }
        }
        .onChange(of: authNetworkManager.isAuth) { isAuthenticated in
            if isAuthenticated {
                showSuccessScreen = true
            }
        }
    }
    
    
    @ViewBuilder
    private func loginMessageScreen() -> some View  {
        VStack{
            Logo()
                .padding()
            
            
            // Instructions
            Text("Before logging in, please sign up at ZynoflixOTT.com")
                .font(.title)
                .fontWeight(.bold)
                .multilineTextAlignment(.center)
                .padding()
            

            // Request Status
            Text("Request Status: \(authNetworkManager.requestStatus)")
                .padding()
                .background(Color.gray.opacity(0.1))
                .cornerRadius(8)
                .font(.subheadline)

            // Error Message
            if let errorMessage = authNetworkManager.errorMessage {
                Text("Error: \(errorMessage)")
                    .foregroundColor(.red)
                    .padding()
                    .background(Color.red.opacity(0.1))
                    .cornerRadius(8)
            }

            // Login Button
            Button(action: {
                authNetworkManager.fetchOtp()
                showOTPInput = true
            }) {
                Text("Login")
                    .font(.headline)
            }
            .padding(.top, 20)

        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }

    // OTP Input Screen
    @ViewBuilder
    private func otpInputScreen() -> some View {
        var otp: String = authNetworkManager.tvOs?.otp ?? "" // Example OTP, this should be dynamic based on your logic

        VStack(spacing: 30) {
            
            Logo()
                .padding()
            
            VStack{
                
                
                Text("Enter code below in the OTTplay mobile app")
                    .font(.headline)
                    .foregroundColor(.white)
                    .multilineTextAlignment(.center)
                
                Text("or www.zynoflixott.com")
                    .font(.caption2)
            }

                    HStack(spacing: 15) {
                        ForEach(otp.map { String($0) }, id: \.self) { digit in
                            Text(digit)
                                .font(.system(size: 70, weight: .bold, design: .monospaced))
                                .foregroundColor(.white)
                                .frame(width: 120, height: 120)
                                .background(Color.purple.opacity(0.8))
                                .cornerRadius(10)
                                .shadow(color: .black.opacity(0.3), radius: 5, x: 0, y: 5)
                        }
                    }

                    Button(action: {
                        // Action for "Not Now" button
                    }) {
                        Text("Not Now")
                            .font(.caption)
                            
                    
                    }
                }
                .padding()
                .background(Color.black.edgesIgnoringSafeArea(.all))
                .cornerRadius(20)
                .padding(.horizontal)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
    }

@ViewBuilder
private func successScreen() -> some View {
    VStack(spacing: 40) {  // Increased spacing for better visibility on TV
        Text("Login Successful!")
            .font(.largeTitle)  // Larger font for visibility
            .fontWeight(.bold)
        

        Text("Welcome to Zynoflix OTT")
            .font(.title)
            .foregroundColor(.white)
            .multilineTextAlignment(.center)
            .padding(.horizontal, 40)  // Extra padding for text on TV screens

        Button(action: {
            // Handle post-login actions
        }) {
            Text("Continue")
                .font(.title2)
                .fontWeight(.bold)// Shadow for button depth
        }
        .buttonStyle(PlainButtonStyle())  // For better tvOS focus animations
        .padding(.horizontal, 60)  // Adequate padding for button on TV
    }
    .padding()
    .background(
        Color.black
            .edgesIgnoringSafeArea(.all)  // Background for full screen on TV
    )
    .frame(maxWidth: .infinity, maxHeight: .infinity)
}




#Preview {
    AuthLoginView()
}
