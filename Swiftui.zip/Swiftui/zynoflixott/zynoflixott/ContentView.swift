import SwiftUI

struct ContentView: View {

    var body: some View {
        HStack(spacing: 0) {
            MainContentView()
        }
        .edgesIgnoringSafeArea(.all)
        .background(Color.black) // Background for the whole view
    }
}


#Preview {
    ContentView()
}
