//
//  ContentView.swift
//  folder
//
//  Created by Gokula Krishnan R on 22/04/24.
//

import SwiftUI

import Foundation

struct ContentView: View {
    @ObservedObject private var recentP = SettingFetcher()
    @State private var searchText = ""
    @State private var successMessage: String?
    @State private var isLoading = false
    @State private var errorMessage: String?
    var body: some View {
        HStack {
            Heroview(successMessage: $successMessage , searchText: $searchText)
            VStack{
                
                Search(searchText: $searchText, placeholder: "Search a workspace or project Name")
                
                listworkspaces(successMessage: $successMessage , searchText: $searchText)
               
            }
            .onAppear {
                self.recentP.fetchRecent()
                if let workspaces = self.recentP.workSpaces?["workspaces"] as? [[String: Any]], !workspaces.isEmpty {
                    if let firstWorkspace = workspaces.first {
                        if let filename = firstWorkspace["filename"] as? String, let path = firstWorkspace["path"] as? String {
                            print("Filename: \(filename), Path: \(path)")
                        }
                    }
                } else {
                    print("No workspaces found or workspace details incomplete")
                }
            }
            
        }
        
    }
 
}



#Preview(){
    ContentView()
}


