//
//  header.swift
//  folder
//
//  Created by Gokula Krishnan R on 25/04/24.
//

import SwiftUI

struct Header: View {
    var body: some View {
        HStack{
            HStack{
                Image(systemName: "folder.fill")
                    .font(.headline)
                Text("vs code workspaces")
                    .font(.headline)
            }
            .padding()
            Spacer()
        }
        .background(Color.yellow.opacity(0.8))
    }
}
