//
//  WorkspaceButton.swift
//  folder
//
//  Created by Gokula Krishnan R on 27/04/24.
//

import SwiftUI

struct WorkspaceButton: View {
    @ObservedObject private var recentP = SettingFetcher()
    var filename: String
    @Binding var searchText: String
    var path: String
    var language: String
    @Binding var successMessage: String?
    @State private var timer: Timer? = nil
    var body: some View {
        Button(action: {
            successMessage = "opeing vscode ..."
            startTimer()
            self.recentP.openTerminal(at: path)
        }) {
            VStack(alignment: .leading , spacing: 0) {
                HStack {
                    Image(systemName: "folder.fill")
                        .font(.system(size: 19))
                        
                    VStack(alignment: .leading) {
                        Text("\(filename)")
                            .font(.headline)
                        Text("\(path)")
                            .font(.subheadline)
                            .lineLimit(1)
                        Text("\(language)")
                            .font(.subheadline)
                            .lineLimit(1)

                    }
                    Spacer()
                    Button(action: {
                        self.recentP.deleteProject(at: path)
                    }, label: {
                        Image(systemName: "minus.circle.fill")
                    })
                    
                }
                .padding(.horizontal , 6)
                .padding(.vertical , 0)
            }
            .buttonStyle(.plain)
            .listStyle(.plain)
            
        }
        .buttonStyle(.plain)
       
   
    }
    func startTimer() {
          timer?.invalidate() // Invalidate previous timer if exists
          timer = Timer.scheduledTimer(withTimeInterval: 3, repeats: false) { _ in
              successMessage = nil // Hide success message after 5 seconds
          }
      }
    private var filteredProjects: String {
//        if searchText.isEmpty {
//            return workspace
//        } else {
//            return workspace?.filter { $0.filename.contains(searchText) }
//        }
        return "hi"
    }
}


