//
//  listworkspaces.swift
//  folder
//
//  Created by Gokula Krishnan R on 27/04/24.
//

import SwiftUI

struct listworkspaces: View {
    @ObservedObject private var recentP = SettingFetcher()
    @Binding var successMessage: String?
    @Binding var searchText: String
    @State private var isLoading = false
    @State private var errorMessage: String?
    
    
    var body: some View {
        VStack {
            if isLoading {
                ProgressView("Loading...")
            } else {
                if let workspaces = recentP.workSpaces?["workspaces"] as? [[String: Any]], !workspaces.isEmpty {
                    ScrollView {
                        VStack(spacing: 5) {
                            ForEach(workspaces.indices, id: \.self) { index in
                                if let filename = workspaces[index]["filename"] as? String,
                                   let path = workspaces[index]["path"] as? String,
                                   let language = workspaces[index]["language"] as? String {
                                    // Check if searchText exists and matches any workspace attribute
                                    if !searchText.isEmpty ? (
                                        filename.localizedCaseInsensitiveContains(searchText)
                                    ):(true) {
                                        WorkspaceButton(filename: filename, searchText: $searchText, path: path , language: language, successMessage: $successMessage)
                                    }
                                   
                                }
                            }
                        }
                    }


                } else {
                    Text("No workspaces found or workspace details incomplete")
                        .padding()
                }
            }
            if let successMessage = successMessage {
                Text(successMessage)
                    .foregroundColor(.green)
                    .padding()
            }
        }

    }
}

