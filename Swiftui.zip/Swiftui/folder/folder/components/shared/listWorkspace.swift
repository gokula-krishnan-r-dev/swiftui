//
//  listWorkspace.swift
//  folder
//
//  Created by Gokula Krishnan R on 25/04/24.
//

import SwiftUI

struct listWorkspace: View {
    @ObservedObject private var recentP = SettingFetcher()
    @Binding var searchText: String
    @Binding var successMessage: String?
    @State private var timer: Timer? = nil
    var workspace: [Workspace]?
    var body: some View {
        VStack{
            if let recentProjects = self.filteredProjects {
                List(recentProjects, id: \.filename) { project in
                    Button(action: {
                        print("Path: \(project.path)")
                        successMessage = "opeing vscode ..."
                        startTimer()
                        recentP.openTerminal(at: project.path)
                    }) {
                        VStack(alignment: .leading) {
                            HStack{
                                
                                Image(systemName: "folder")
                                    .font(.headline)
                                    
                                VStack(alignment: .leading) {
                                    Text("\(project.filename)")
                                        .font(.headline)
                                    Text("\(project.path)")
                                        .font(.subheadline)
                                        .lineLimit(1)
                                }
                                
                                Spacer()
                                Button(action: {
                                    recentP.deleteProject(at: project.path)
                                }, label: {
                                    Image(systemName: "minus.circle.fill")
                                })
                             
                            }
                            .padding(.horizontal , 6)
                            .padding(.vertical , 8)
                        }
                        
                    }
                    .buttonStyle(.plain)
                    .listStyle(.plain)
                    
                }
                .listStyle(.plain)
                .buttonStyle(.plain)
               
            } else {
                Text("Loading recent projects...")
                    .padding()
            }
            if let successMessage = successMessage {
                Text(successMessage)
                    .foregroundColor(.green)
                    .padding()
            }
            
        }
    }
    func startTimer() {
          timer?.invalidate() // Invalidate previous timer if exists
          timer = Timer.scheduledTimer(withTimeInterval: 3, repeats: false) { _ in
              successMessage = nil // Hide success message after 5 seconds
          }
      }
    private var filteredProjects: [Workspace]? {
        if searchText.isEmpty {
            return workspace
        } else {
            return workspace?.filter { $0.filename.contains(searchText) }
        }
    }
}


