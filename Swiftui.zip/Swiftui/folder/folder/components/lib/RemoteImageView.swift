//
//  RemoteImageView.swift
//  folder
//
//  Created by Gokula Krishnan R on 25/04/24.
//

import SwiftUI

struct RemoteImageView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    RemoteImageView()
}
