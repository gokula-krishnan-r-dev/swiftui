//
//  Heroview.swift
//  folder
//
//  Created by Gokula Krishnan R on 26/04/24.
//

import SwiftUI
import Foundation
struct Heroview: View {
    @Environment(\.presentationMode) var presentationMode
    @ObservedObject private var recentP = SettingFetcher()
    @Binding var successMessage: String?
    @Binding var searchText: String
    @State private var isLoading = false
    @State private var errorMessage: String?
    var body: some View {
        VStack(spacing: 20) {
            HStack {
                Button(action: {
                              self.presentationMode.wrappedValue.dismiss()
                          }) {
                              Image(systemName: "xmark.circle.fill")
                                  .font(.headline)
                          }
                          .buttonStyle(.plain)
                Spacer()
            }
            .padding(.horizontal)
            
            VStack(spacing: 10) {
                Image("vscode")
                    .resizable()
                    .frame(width: 100, height: 100)
                    .shadow(color: .gray.opacity(0.5), radius: 10, x: 0, y: 0)
                HStack{
                    Text("VS Code Workspace")
                        .font(.title)
                        .fontWeight(.bold)
                    
                    Button {
                        withAnimation {
                            isLoading.toggle()
                            self.recentP.fetchWorkspaces()
                            isLoading.toggle()
                        }
                    } label: {
                        Image(systemName: "arrow.clockwise")
                            .font(.system(size: 18))
                    }
                    .buttonStyle(.plain)
                    .rotationEffect(.degrees(isLoading ? 360 : 0))                     .animation(Animation.linear(duration: 1))


                  
                }
                Text("Version 0.0.1")
                    .font(.subheadline)
                    .foregroundColor(.gray)
            }
            .padding(.horizontal)
            
            
            VStack() {
                if isLoading {
                    ProgressView("Loading...")
                } else {
                    if let workspaces = recentP.workSpaces?["recent_project"] as? [[String: Any]] {
                        ScrollView {
                            VStack(spacing: 5) {
                                if workspaces.isEmpty {
                                    Text("No workspaces found")
                                        .padding()
                                } else {
                                    ForEach(workspaces.indices, id: \.self) { index in
                                        if let submenu = workspaces[index]["submenu"] as? [String: Any],
                                           let items = submenu["items"] as? [[String: Any]] {
                                            ForEach(items.indices, id: \.self) { itemIndex in
                                                if let item = items[itemIndex] as? [String: Any],
                                                   let uri = item["uri"] as? [String: Any],
                                                   let path = uri["path"] as? String {
                                                    let label = URL(fileURLWithPath: path).lastPathComponent
                                                    // Use label here
                                                    WorkspaceButton(filename: label, searchText: $searchText, path: path, language: "", successMessage: $successMessage)

                                                }
                                            }
                                            .padding(.horizontal , 8)
                                        } else {
                                            Text("No workspaces found or workspace details incomplete")
                                                .padding()
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        Text("No workspaces found")
                            .padding()
                    }
                }
            }


        }
        .padding(.vertical , 12)
    }
}



#Preview(){
    ContentView()
}
