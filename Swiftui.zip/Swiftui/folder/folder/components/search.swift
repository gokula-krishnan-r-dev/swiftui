//
//  search.swift
//  folder
//
//  Created by Gokula Krishnan R on 25/04/24.
//
import SwiftUI
struct Search: View {
    @Binding var searchText: String
    var placeholder: String

    
    var body: some View {
        HStack {
            HStack{
                
                Image(systemName: "folder.fill")
                    .font(.system(size: 18))
                
                TextField(placeholder, text: $searchText)
                    .textFieldStyle(.plain)
                    .font(.system(size: 14))
                    .foregroundColor(.white)
                
                
            }
            .padding(.vertical , 14)
            .padding(.horizontal , 12)
            .background(Color.gray.opacity(0.3))
            .cornerRadius(55)
        }
        .padding(.top, 12)
        .padding(.horizontal , 12)
    }
        
}

#Preview(){
    ContentView()
}
