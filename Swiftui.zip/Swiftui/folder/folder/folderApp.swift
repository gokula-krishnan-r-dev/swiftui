//
//  folderApp.swift
//  folder
//
//  Created by Gokula Krishnan R on 22/04/24.
//

import SwiftUI

@main
struct folderApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
        .windowStyle(HiddenTitleBarWindowStyle())
        .windowStyle(.hiddenTitleBar)
    }
}
