//
//  ContentView.swift
//  notes-app
//
//  Created by Gokula Krishnan R on 06/01/24.
//

import SwiftUI

struct ContentView: View {
    let customColor = Color(
                red: Double(0xEB) / 255.0,
                green: Double(0x7A) / 255.0,
                blue: Double(0x53) / 255.0
            )

    @State private var isChecked = false
    let todoItems = [
           Tab(userId: 1, id: 1, title: "All", completed: false),
           Tab(userId: 2, id: 2, title: "Working", completed: false),
           Tab(userId: 3, id: 3, title: "Gym", completed: false),
           Tab(userId: 4, id: 4, title: "To-do", completed: false),
           Tab(userId: 5, id: 5, title: "quis ut nam facilis et officia qui", completed: false),
       ]
    var body: some View {
        VStack(alignment: .leading) {
            VStack(alignment: .leading){
                Text("My\nNotes")
                    .foregroundColor(.white)
                    .font(.system(size: 60))
                    .fontWeight(.medium)
                    .multilineTextAlignment(.leading)
            }
            ScrollView(.horizontal , showsIndicators: false) {
                       HStack {
                           ForEach(todoItems, id: \.id) { todoView in
                               HStack{
                                   Tab(userId: todoView.userId, id: todoView.id, title: todoView.title, completed: todoView.completed)
                                       .frame(maxWidth: .infinity)
                               }   
                           }
                       }
                       
                   }
            .padding(.vertical , 10)
            HStack{
             CardView()
            CardView()
            }
            VStack{
                MultiNoteView()
            }
        }
        .padding(.horizontal , 12)
        .frame(maxWidth: .infinity)
        
        
    }
    
}

struct CheckboxToggleStyle: ToggleStyle {
  func makeBody(configuration: Self.Configuration) -> some View {
    HStack {
      Image(systemName: configuration.isOn ? "checkmark.circle.fill" : "circle")
        .resizable()
        .frame(width: 24, height: 24)
        .onTapGesture { configuration.isOn.toggle() }
        configuration.label
        Spacer()
    }
    .padding(12)
    .font(.headline)
    .foregroundColor(.black)
    }
}

#Preview {
    ContentView()
}
