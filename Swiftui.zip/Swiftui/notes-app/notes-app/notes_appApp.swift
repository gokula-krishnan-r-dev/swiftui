//
//  notes_appApp.swift
//  notes-app
//
//  Created by Gokula Krishnan R on 06/01/24.
//

import SwiftUI

@main
struct notes_appApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
            
        }
    }
}
