//
//  CheckBoxView.swift
//  notes-app
//
//  Created by Gokula Krishnan R on 09/01/24.
//

import SwiftUI

struct CheckBoxView: View {
    @State private var isChecked = false
    var body: some View {
            VStack{
                Toggle("GYM", isOn: $isChecked)
                    .toggleStyle(CheckboxToggleStyle())
                
            }
            .background(Color(red: 0.87, green: 0.45, blue: 0.31))
            .cornerRadius(55)
        }
    }

#Preview {
    CheckBoxView()
}
