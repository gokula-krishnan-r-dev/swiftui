//
//  Tab.swift
//  notes-app
//
//  Created by Gokula Krishnan R on 06/01/24.
//

import SwiftUI

struct Tab: View {
    let userId: Int
       let id: Int
       let title: String
       let completed: Bool
    var body: some View {
        HStack{
            HStack{
                Text("\(title)")
                    .font(.system(size: 16))
                    .fontWeight(.semibold)
                if completed {
                    Text("\(userId)")
                        .cornerRadius(45)
                        .padding(.horizontal , 4)
                        .padding(.vertical , 4)
                        .background(Color(red: 38/255, green: 38/255, blue: 38/255))
                        .clipShape(Capsule())
                }
            }
            .padding(.horizontal , 18)
            .padding(.vertical , 15)
        }
        .foregroundColor(Color.white)
        .background(.black)
        .cornerRadius(45)
        .overlay(
            RoundedRectangle(cornerRadius: 45)
                .inset(by: 0.5)
                .stroke(.white, lineWidth: 1)
        )
    }
}

#Preview {
    Tab(userId: 1, id: 1, title: "All", completed: false)
}
