//
//  LandingView.swift
//  autocommentIq Watch App
//
//  Created by Gokula Krishnan R on 01/04/24.
//

import SwiftUI

struct LandingView: View {
    @ObservedObject var videofetcher = Videofetcher()
    
    @State private var showActivity: Bool = false
    @State private var selectedVideo: Video?

    var body: some View {
        ScrollView{
            
            HStack{
                VStack(alignment: .leading){
                    Text("Hi Gokula 👋")
                        .font(.system(size: 16))
                        .fontWeight(.bold)
                    Text("Here&#39s what&#39s happening with your projects today 👇")
                        .font(.system(size: 12))
                }
               
            }
            
            SubCount()
            SubChart()
            
            if let videos = self.videofetcher.videos {
                    if videos.videos.isEmpty {
                        Text("No videos available")
                    } else {
                        ForEach(videos.videos, id: \.self.videoID) { video in
                            Button(action: {
                                selectedVideo = video
                                showActivity = true
                            }) {
                                VideoSection(video: video)
                            }
                            .onAppear{
                                selectedVideo = video
                            }
                            .sheet(isPresented: $showActivity) {
                                       if let selectedVideo = selectedVideo {
                                           NavigationView {
                                               NextVideoView(video: selectedVideo)
                                           }
                                       } else {
                                           Text("No video selected")
                                       }
                                   }
                            .buttonStyle(.plain)
                        }
                    }
                } else {
                    // Display a placeholder or loading indicator
                    Text("Loading...")
                }
          
        }
        .onAppear{
            self.videofetcher.fetchVideo()
        }
        
    }
}

#Preview {
    ContentView()
}
