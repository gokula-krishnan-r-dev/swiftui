import SwiftUI

struct CommentView: View {
    @ObservedObject var commentFetcher = CommentFetcher()
    var videoId: String = ""
    var body: some View {
        NavigationView {
            
            if !self.commentFetcher.data.isEmpty {
                CommentListView(comments: self.commentFetcher.data)
                    .navigationTitle(
                        Text("Comments")
                            .font(.system(size: 10))
                    )
            } else {
                // You can show a loading indicator or placeholder here
                Text("Loading...")
            }
        }
        .onAppear {
            self.commentFetcher.fetchData(videoId: videoId)
            print(self.commentFetcher.data)
        }
    }
}




struct ContentViewPreviews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}


