import SwiftUI

struct ContentView: View {
    @State private var scrollID = UUID()
    @State private var activeIndex: Int?
    
    var body: some View {
        HStack{
//            CommentView()
            LandingView()
        }
       
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
