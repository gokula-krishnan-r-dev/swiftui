//
//  autocommentIqApp.swift
//  autocommentIq Watch App
//
//  Created by Gokula Krishnan R on 09/03/24.
//

import SwiftUI

@main
struct autocommentIq_Watch_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
