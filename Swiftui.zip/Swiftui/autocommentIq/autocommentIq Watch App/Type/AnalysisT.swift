//
//  AnalysisT.swift
//  autocommentIq Watch App
//
//  Created by Gokula Krishnan R on 01/04/24.
//

import Foundation

// MARK: - AnalysisT
struct AnalysisT: Codable, Identifiable {
    let id = UUID() // Adding an id property
    let values: AnalysisTValues
    let totalValue: Int
}

// MARK: - Values
struct AnalysisTValues: Codable {
    let subscribersGained: [AnalysisTSubscribersGained]
    let views: [AnalysisTView]
    let likes: [AnalysisTLike]
    let comments: [AnalysisTCommentElement1]
    let estimatedMinutesWatched: [AnalysisTEstimatedMinutesWatched]
    let averageViewDuration: [AnalysisTAverageViewDuration]
    let shares: [AnalysisTShare]
    let dislikes: [AnalysisTDislike]
    let annotationClickThroughRate: [AnalysisTAnnotationClickThroughRate]
    let annotationCloseRate: [AnalysisTAnnotationCloseRate]
    let annotationImpressions: [AnalysisTAnnotationImpression]
    let viewsPerPlaylistStart: [AnalysisTViewsPerPlaylistStart]
    let averageTimeInPlaylist: [AnalysisTAverageTimeInPlaylist]
}

// MARK: - AnalysisTAnnotationClickThroughRate
struct AnalysisTAnnotationClickThroughRate: Codable, Identifiable {
    let id = UUID() // Adding an id property
    let date: String
    let annotationClickThroughRate: Int
}

// MARK: - AnalysisTAnnotationCloseRate
struct AnalysisTAnnotationCloseRate: Codable, Identifiable {
    let id = UUID() // Adding an id property
    let date: String
    let annotationCloseRate: Int
}

// MARK: - AnalysisTAnnotationImpression
struct AnalysisTAnnotationImpression: Codable, Identifiable {
    let id = UUID() // Adding an id property
    let date: String
    let annotationImpressions: Int
}

// MARK: - AnalysisTAverageTimeInPlaylist
struct AnalysisTAverageTimeInPlaylist: Codable, Identifiable {
    let id = UUID() // Adding an id property
    let date: String
    let averageTimeInPlaylist: Int
}

// MARK: - AnalysisTAverageViewDuration
struct AnalysisTAverageViewDuration: Codable, Identifiable {
    let id = UUID() // Adding an id property
    let date: String
    let averageViewDuration: Int
}

// MARK: - AnalysisTCommentElement
struct AnalysisTCommentElement1: Codable, Identifiable {
    let id = UUID() // Adding an id property
    let date: String
    let comments: Int
}

// MARK: - AnalysisTDislike
struct AnalysisTDislike: Codable, Identifiable {
    let id = UUID() // Adding an id property
    let date: String
    let dislikes: Int
}

// MARK: - AnalysisTEstimatedMinutesWatched
struct AnalysisTEstimatedMinutesWatched: Codable, Identifiable {
    let id = UUID() // Adding an id property
    let date: String
    let estimatedMinutesWatched: Int
}

// MARK: - AnalysisTLike
struct AnalysisTLike: Codable, Identifiable {
    let id = UUID() // Adding an id property
    let date: String
    let likes: Int
}

// MARK: - AnalysisTShare
struct AnalysisTShare: Codable, Identifiable {
    let id = UUID() // Adding an id property
    let date: String
    let shares: Int
}

// MARK: - AnalysisTSubscribersGained
struct AnalysisTSubscribersGained: Codable, Identifiable {
    let id = UUID() // Adding an id property
    let date: String
    let subscribersGained: Int
}

// MARK: - AnalysisTView
struct AnalysisTView: Codable, Identifiable {
    let id = UUID() // Adding an id property
    let date: String
    let views: Int
}

// MARK: - AnalysisTViewsPerPlaylistStart
struct AnalysisTViewsPerPlaylistStart: Codable, Identifiable {
    let id = UUID() // Adding an id property
    let date: String
    let viewsPerPlaylistStart: Int
}
