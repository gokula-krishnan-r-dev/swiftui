//
//  testingApp.swift
//  testing
//
//  Created by Gokula Krishnan R on 10/02/24.
//

import SwiftUI

@main
struct testingApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
