//
//  autocomment_IOSApp.swift
//  autocomment-IOS
//
//  Created by Gokula Krishnan R on 02/04/24.
//

import SwiftUI

@main
struct autocommentIOSApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
