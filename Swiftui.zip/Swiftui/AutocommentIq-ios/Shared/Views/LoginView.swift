//
//  LoginView.swift
//  AutocommentIq-ios
//
//  Created by Gokula Krishnan R on 12/04/24.
//

import SwiftUI


struct LoginView: View {
    @EnvironmentObject var authViewModel: AuthViewModel
    @State private var otp: String = ""
    @AppStorage("accessToken") var accessToken: String?
    var body: some View {
        VStack() {
            Text("Please log in to continue")
                .font(.headline)
                .padding(.top, 20)

            TextField("Enter OTP", text: $otp)
                .padding()
                .cornerRadius(5)
            
            Button("Login") {
                authViewModel.login(otp: otp) // Pass the OTP to the login function
            }
            .padding()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .edgesIgnoringSafeArea(.all)
    }
}
