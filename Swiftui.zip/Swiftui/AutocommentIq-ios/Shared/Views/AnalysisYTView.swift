//
//  AnalysisYTView.swift
//  autocomment-IOS
//
//  Created by Gokula Krishnan R on 02/04/24.
//

import SwiftUI
import Charts
struct AnalysisYTView: View {
    var analysisYT: AnalysisTValues?
    var body: some View {
        ScrollView{
            if let analysisData = self.analysisYT {
                VStack{
                    VStack{
                        
                        
                        Text("subscribersGained")
                            .font(.system(size: 12))
                            .bold()
                        
                        Text("Total Sub: \(analysisData.subscribersGained_total_count) -> Percentage = \(analysisData.subscribersGained_percentageChange)")
                    }
                    Chart(analysisData.subscribersGained  ) {
                        LineMark(
                            x: .value("Month", $0.date),
                            y: .value("Subscribers Gained", $0.subscribersGained)
                        )
                        .interpolationMethod(.catmullRom)
                        
                        AreaMark(
                            x: .value("Month", $0.date),
                            y: .value("Subscribers Gained", $0.subscribersGained)
                        )
                        .interpolationMethod(.catmullRom)
                        .foregroundStyle(Color("Blue").opacity(0.1).gradient)
                    }
                    .padding()
                    .chartYAxis() {
                        AxisMarks(position: .leading)
                    }
                    .frame(height: 100)
                    .chartLegend(position: .overlay, alignment: .top)
                    .padding(.vertical , 12)
                
                }
                
                VStack{
                    HStack{
                        Text("views")
                            .font(.system(size: 12))
                            .bold()
                        Spacer()
                    }
                    Chart(analysisData.views  ) {
                        LineMark(
                            x: .value("Month", $0.date),
                            y: .value("Subscribers Gained", $0.views)
                        )
                        .interpolationMethod(.catmullRom)
                        
                        AreaMark(
                            x: .value("Month", $0.date),
                            y: .value("Subscribers Gained", $0.views)
                        )
                        .interpolationMethod(.catmullRom)
                        .foregroundStyle(Color("Blue").opacity(0.1).gradient)
                    }
                    .padding()
                    .chartYAxis() {
                        AxisMarks(position: .leading)
                    }
                    .frame(height: 100)
                    .chartLegend(position: .overlay, alignment: .top)
                    .padding(.vertical , 12)
                
                }
                VStack{
                    HStack{
                        Text("comments")
                            .font(.system(size: 12))
                            .bold()
                        Spacer()
                    }
                    Chart(analysisData.comments  ) {
                        LineMark(
                            x: .value("Month", $0.date),
                            y: .value("Subscribers Gained", $0.comments)
                        )
                        .interpolationMethod(.catmullRom)
                        
                        AreaMark(
                            x: .value("Month", $0.date),
                            y: .value("Subscribers Gained", $0.comments)
                        )
                        .interpolationMethod(.catmullRom)
                        .foregroundStyle(Color("Blue").opacity(0.1).gradient)
                    }
                    .padding()
                    .chartYAxis() {
                        AxisMarks(position: .leading)
                    }
                    .frame(height: 100)
                    .chartLegend(position: .overlay, alignment: .top)
                    .padding(.vertical , 12)
                
                }
                
                
                          } else {
                              ProgressView()
                          }
        }
    }
}

