//
//  main.swift
//  autocomment-IOS
//
//  Created by Gokula Krishnan R on 02/04/24.
//

import SwiftUI

struct autocommentView: View {
    @StateObject private var authViewModel = AuthViewModel()
    
    var body: some View {
        HStack {
//            if authViewModel.isAuthenticated {
//            #if os(tvOS)
//                LandingTvosView()
//            #else
            
                
            NavigationView{
                
                
                LandingView()
            }
//            #endif
//            } else {
//                LoginView()
//            }
        }
//        .environmentObject(authViewModel)
    }
}
