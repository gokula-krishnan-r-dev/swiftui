//
//  NextVideoView.swift
//  autocommentIq Watch App
//
//  Created by Gokula Krishnan R on 01/04/24.
//

import SwiftUI

struct NextVideoView: View {
    var video: Video

    var body: some View {
        ScrollView {
                       VStack {
                           Text("Hello World")
                           NavigationLink(destination: CommentView(videoId: video.videoID)) {
                               Text("See Comments")
                           }
                       }
            VStack(alignment: .leading, spacing: 10) {
                Text(video.title)
                    .font(.system(size: 14))
                    .lineLimit(/*@START_MENU_TOKEN@*/2/*@END_MENU_TOKEN@*/)
                    .fontWeight(.bold)
                RemoteImage(url: video.thumbnailURL)
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 170, height: 100)
                    .clipped()
                    .cornerRadius(10)
            }
            .padding(10)
            .background(Color.gray.opacity(0.30))
            .cornerRadius(10)
            .shadow(radius: 5)
        }
        .padding()
        
        
    }
}

#Preview {
    ContentView()
}
struct RemoteImage: View {
    let url: String

    var body: some View {
        if let imageUrl = URL(string: url), let imageData = try? Data(contentsOf: imageUrl), let uiImage = UIImage(data: imageData) {
            Image(uiImage: uiImage)
                .resizable()
        } else {
            Image(systemName: "photo")
                .resizable()
        }
    }
}
