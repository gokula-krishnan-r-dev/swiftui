//
//  LandingView.swift
//  autocommentIq Watch App
//
//  Created by Gokula Krishnan R on 01/04/24.
//

import SwiftUI

struct LandingView: View {
    @ObservedObject private var videofetcher = Videofetcher()
    @ObservedObject private var broadcasts = BroadcastsNetwork()
    @State private var showActivity: Bool = false
    @State private var selectedVideo: Video?
    @State private var showSubChart = false
        
    var body: some View {
        ScrollView { 
            HStack{
                VStack(alignment: .leading){
                    Text("Hi Gokula 👋")
                        .font(.system(size: 16))
                        .fontWeight(.bold)
                    Text("Here&#39s what&#39s happening with your projects today 👇")
                        .font(.system(size: 12))
                }
               
            }
            
            SubCount()
            
//            if showSubChart {
//                          SubChart()
//            }else{
//                ProgressView()
//            }
            RoomSlider()
//            BroadcastsList(data: broadcasts.broadcasts)
            if let videos = self.videofetcher.videos {
                if videos.videos.isEmpty {
                    Text("No videos available")
                } else {
                    ForEach(videos.videos, id: \.self.videoID) { video in
                        NavigationLink(destination: NextVideoView(video: video)) {
                            VideoSection(video: video)
                        }
                        .buttonStyle(PlainButtonStyle())
                    }
                }
            } else {
                Text("Loading...")
            }
        }
        .onAppear{
            DispatchQueue.main.asyncAfter(deadline: .now() + 12) {
                           self.showSubChart = true
                       }
            self.videofetcher.fetchVideo()
            self.broadcasts.fetchBroadcast()
        }
        
    }
}

#Preview {
    ContentView()
}
