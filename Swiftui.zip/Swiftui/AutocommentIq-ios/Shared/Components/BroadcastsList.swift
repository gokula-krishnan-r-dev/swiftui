import SwiftUI

import SwiftUI


struct AsyncImage: View {
    let url: URL?
    
    var body: some View {
        if let url = url, let imageData = try? Data(contentsOf: url), let uiImage = UIImage(data: imageData) {
            Image(uiImage: uiImage)
                .resizable()
        } else {
            Image(systemName: "photo")
                .resizable()
        }
    }
}

struct BroadcastsList: View {
    var data: [BroadcastT]?
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    if let broadcastsData = data {
                        ForEach(broadcastsData) { broadcast in
                            NavigationLink(destination: BroadcastDetailsView(broadcast: broadcast)) {
                                BroadcastRow(broadcast: broadcast)
                            }
                            .buttonStyle(PlainButtonStyle())
                        }
                    } else {
                        ProgressView("Loading...")
                            .progressViewStyle(CircularProgressViewStyle())
                            .padding()
                    }
                }
                .padding()
            }
            .navigationBarTitle("Live Stream Events")
        }
    }
}

