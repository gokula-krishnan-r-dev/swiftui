//
//  SubCount.swift
//  autocommentIq Watch App
//
//  Created by Gokula Krishnan R on 01/04/24.
//

import SwiftUI

struct SubCount: View {
    @StateObject var websocket = Websocket()
    
    var body: some View {
        VStack(alignment: .leading){
            HStack (alignment: .top) {
                RemoteImage(url: "https://yt3.ggpht.com/T9IuKawbxOW0FXuRNNUbQaZPC7VuNu-GXW4lDLCW6-kKqFaCQViXgVUpB_fzaslXU-c1W3W-=s800-c-k-c0x00ffffff-no-rj")
                                                             .aspectRatio(contentMode: .fit)
                                                             .frame(width: 84, height: 84)
                                                             .clipShape(Circle())
                Spacer()
                

                RemoteImage(url: "https://www.freeiconspng.com/thumbs/youtube-logo-png/youtube-logo-icon-symbol-18.png")
                    .aspectRatio(contentMode: .fit)
                                                .frame(width: 33, height: 33)
                                                .clipShape(Circle())
            }
        
            Text("\(websocket.messages.first?.user.first?.count ?? "channel Name")")
                          .font(.headline)
                      
            HStack {
                Text("\(self.websocket.messages.first?.counts.first?.count ?? 1)")
                                   .font(.system(size: 20))
                                   .fontWeight(.bold)
                                   .foregroundStyle(.red)
            }
            
            Text("Total Subscribers")
                .font(.system(size: 12))
        }
        .onAppear{
            self.websocket.objectWillChange.send()
        }
        .padding(14)
        .background(Color.gray.opacity(0.3))
        .cornerRadius(22)
    }
}

#Preview {
    ContentView()
}
