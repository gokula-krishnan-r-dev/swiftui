//
//  ListChat.swift
//  AutocommentIq-ios
//
//  Created by Gokula Krishnan R on 08/04/24.
//

import SwiftUI

struct ListChat: View {
    @State private var selectedRoom: Room? = nil
    var rooms: [Room]

    var body: some View {
        NavigationView {
            List(rooms) { room in
                RoomCard(room: room)
                    .onTapGesture {
                        self.selectedRoom = room
                    }
            }
            .navigationBarTitle("Rooms")
        }
        .sheet(item: self.$selectedRoom) { room in
            RoomDetailView(room: room)
        }
    }
}

