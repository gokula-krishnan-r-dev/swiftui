//
//  VideoSection.swift
//  autocommentIq Watch App
//
//  Created by Gokula Krishnan R on 01/04/24.
//

import SwiftUI


struct VideoSection: View {
    var video: Video
    let isTvOS: Bool = {
        #if os(tvOS)
            return true
        #else
            return false
        #endif
    }()
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(video.title)
                .font(.system(size: isTvOS ? 24 : 14))
                .lineLimit(2)
                .fontWeight(.bold)
            RemoteImage(url: video.thumbnailURL)
                .aspectRatio(contentMode: .fill)
                .frame(height:isTvOS ? 350 :  100)
                .clipped()
                .cornerRadius(10)

        }
        .padding(10)
        .background(Color.gray.opacity(0.30))
        .cornerRadius(24)
        .shadow(radius: 5)
    }
}






