//
//  list_video.swift
//  AutocommentIq-ios
//
//  Created by Gokula Krishnan R on 08/04/24.
//

import SwiftUI

struct List_video: View {
    @ObservedObject private var videofetcher = Videofetcher()
    var body: some View {
                   VStack {
                       if let videos = self.videofetcher.videos {
                           if videos.videos.isEmpty {
                               Text("No videos available")
                           } else {
                               ForEach(videos.videos, id: \.self.videoID) { video in
                                   NavigationLink(destination: NextVideoView(video: video)) {
                                       VideoSection(video: video)
                                   }
                                   .buttonStyle(.plain)
                               }
                           }
                       } else {
                           
                           Text("Loading...")
                       }
                   }
                   .onAppear{
                       self.videofetcher.fetchVideo()
                   }
    }
}


