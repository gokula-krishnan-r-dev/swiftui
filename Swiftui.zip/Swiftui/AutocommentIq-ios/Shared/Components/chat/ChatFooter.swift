//
//  ChatFooter.swift
//  AutocommentIq-ios
//
//  Created by Gokula Krishnan R on 08/04/24.
//

import SwiftUI

struct ChatFooter: View {
    @State private var newMessage: String = ""
    @State private var isTextOpen: Bool = false
    var body: some View {
        //             Footer with text input
        ZStack {
                 Spacer()
                  
                 
                     if isTextOpen {
                         TextField("Type your message", text: $newMessage)
                             .textFieldStyle(.automatic)
                             .onSubmit {
                                 
                             }
                     } else {
                         Button(action: {
                             isTextOpen.toggle()
                         }) {
                             Image(systemName: "pencil.and.scribble")
                                 .resizable()
                                 .padding()
                                 .background(Color.gray.opacity(0.3))
                                 .frame(width: 34, height: 34)
                                 .clipShape(Circle())
                         }
                         .buttonStyle(.plain)
                     }
             
             }
         
    }
}
