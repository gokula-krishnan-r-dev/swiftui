//
//  CustomAlertView.swift
//  AutocommentIq-ios
//
//  Created by Gokula Krishnan R on 22/04/24.
//

import SwiftUI

struct CustomAlertView: View {
    var title: String
    var emotes: [Emote] // Assuming this is your Emote model
    var body: some View {
        VStack {
            Text(title)
                .font(.headline)
                .padding(.top)
            
            ForEach(emotes, id: \.id) { emote in
                HStack {
                    Image(systemName: "person.fill") // Placeholder image
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 30, height: 30)
                    
                    Text("\(emote.user.username): \(emote.emoteString)")
                }
                .padding()
            }
            
            Button(action: {
                // Close the alert
            }) {
                Text("Close")
            }
            .padding(.bottom)
        }
        .padding()
        .background(Color.white)
        .cornerRadius(10)
        .shadow(radius: 10)
    }
}


