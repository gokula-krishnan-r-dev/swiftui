//
//  RoomCard.swift
//  AutocommentIq-ios
//
//  Created by Gokula Krishnan R on 08/04/24.
//

import SwiftUI

struct RoomCard: View {
    var room: Room

    var body: some View {
        VStack(alignment: .leading) {
            ZStack(alignment: .topTrailing) {
                            RemoteImage(url: room.videoThumbnail)
                                .frame(height: 100)
                                .cornerRadius(18, antialiased: true)
                            
                            Text("23")
                                .font(.system(size: 12))
                                .fontWeight(.bold)
                                .foregroundColor(.white)
                                .padding(6)
                                .background(Color.red)
                                .clipShape(Circle())
                                .offset(x: -8, y: 5)
                        }
        
            Text(room.name)
                .font(.system(size: 14))
                .lineLimit(2)
                .fontWeight(.medium)
        }
        .padding(.vertical , 8)
        .cornerRadius(12)
    }
}
