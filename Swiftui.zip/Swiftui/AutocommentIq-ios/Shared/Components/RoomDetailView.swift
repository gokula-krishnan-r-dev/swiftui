import SwiftUI

struct RoomDetailView: View {
    var room: Room
    @ObservedObject var viewMessage = RoomViewModel()
    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
       
    
    var body: some View {
        VStack {
            // Header
            ChatHeader(room: room)
            ZStack(alignment:.bottomTrailing){
                
                
                // List of messages
                chatMessage(room: room, messages: viewMessage.message)
                
                ChatFooter()
            }
        }
        .onAppear {
            self.viewMessage.fetchMessage(Id: room.roomId)
//            print("room.roomId" , self.viewMessage.message)
        }
        .onReceive(timer) { _ in
                   // Fetch messages periodically
                   self.viewMessage.fetchMessage(Id: room.roomId)
               }
    }
}

