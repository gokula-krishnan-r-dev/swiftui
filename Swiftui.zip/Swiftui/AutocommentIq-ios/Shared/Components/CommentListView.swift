//
//  CommentListView.swift
//  autocommentIq Watch App
//
//  Created by Gokula Krishnan R on 30/03/24.
//

import SwiftUI

struct CommentListView: View {
    let comments: [CommentElement]
    @State private var isCommentDetailPresented = false
    @StateObject var commentFetcher = CommentFetcher()
    @State private var selectedComment: CommentElement?
    init(comments: [CommentElement]) {
            self.comments = comments
            _selectedComment = State(initialValue: comments.first)
        }
    var body: some View {
        List {
            ForEach(comments, id: \.id) { comment in
                Button(action: {
                    selectedComment = comment
                    isCommentDetailPresented = true
                }) {
                    CommentRow(comment: comment)
                }
            }
          
            Button(action: {
                commentFetcher.refetchData(pageToken: comments[0].nextPageToken, videoId: comments[0].videoID)
            }) {
                Text("Refetch Comments")
                    .foregroundColor(.blue)
            }
            .frame(width: 100, height: 30)
        }
        .listStyle(.automatic) // Using DefaultListStyle for watchOS
        .sheet(isPresented: $isCommentDetailPresented) {
            if let selectedComment = selectedComment {
                CommentDetail(comment: selectedComment, isreply: false)
            }else{
                Text("loading ...")
            }
        }
    }
}



