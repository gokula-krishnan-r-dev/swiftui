import SwiftUI

struct BroadcastDetailsView: View {
    let broadcast: BroadcastT
    @ObservedObject var chat = BroadcastsNetwork()
    
    @State private var inputText = ""
    
    var body: some View {
        ZStack(alignment: .bottom) {
            ScrollView {
                VStack(alignment: .leading) {
                    Text(broadcast.title)
                        .font(.title)
                        .fontWeight(.bold)
                        .padding(.top, 8)
                        .padding(.horizontal)
                    
                    VStack {
                        TextField("Enter your message", text: $inputText)
                            .padding()
                            .font(.system(size: 12))
                            .onChange(of: inputText) { newValue in
                                chat.postMessageToLiveChat(liveChatId: "KicKGFVDYXlKQktvdXJxWE1FbWtKekdQenJYQRILOURoS0Z6YmFYbjQ", message: newValue) { result in
                                    self.chat.fetchLiveChat(id: "KicKGFVDYXlKQktvdXJxWE1FbWtKekdQenJYQRILOURoS0Z6YmFYbjQ")
                                    self.chat.fetchLiveChat(id: "KicKGFVDYXlKQktvdXJxWE1FbWtKekdQenJYQRILOURoS0Z6YmFYbjQ")
                                }
                                
                            }
                    }

                    ForEach(chat.chatMessage ?? [], id: \.id) { message in
                        VStack(alignment: .leading, spacing: 8) {
                            HStack {
                                ZStack(alignment: .topTrailing) {
                                    AsyncImage(url: URL(string: "\(message.authorDetails.profileImageUrl)"))
                                        .frame(width: 34, height: 34)
                                        .cornerRadius(12)
                                    
                                    if message.authorDetails.isVerified {
                                        Image(systemName: "star") // Change "star" to your badge icon name
                                            .foregroundColor(.yellow) // Adjust color as needed
                                            .frame(width: 12, height: 12)
                                            .padding(4)
                                    }
                                }
                                
                                Text(message.authorDetails.displayName)
                                    .font(.system(size: 10))
                                    .fontWeight(.semibold)
                                
                                Spacer()
                            }
                            
                            Text(message.snippet.textMessageDetails.messageText)
                                .font(.body)
                        }
                        .padding(.vertical, 6)
                        Divider()
                            .background(Color.gray.opacity(0.3))
                            .padding(.vertical , 4)
                    }
                    .padding(.horizontal)
                }
            }
        }
        .onAppear {
            self.chat.fetchLiveChat(id: "KicKGFVDYXlKQktvdXJxWE1FbWtKekdQenJYQRILOURoS0Z6YmFYbjQ")
        }
        .navigationBarTitle(broadcast.title)
    }
}
