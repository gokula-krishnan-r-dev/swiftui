//
//  LandingTvosView.swift
//  autocomment-IOS
//
//  Created by Gokula Krishnan R on 04/04/24.
//

import SwiftUI

struct LandingTvosView: View {
    @StateObject var websocket = Websocket()
    @ObservedObject private var videofetcher = Videofetcher()
    
    @State private var showActivity: Bool = false
    @State private var selectedVideo: Video?
    var body: some View {
        ScrollView(){
            HStack(alignment: .top){
                VStack(alignment: .leading){
                    Text("Hi GOKULA KRISHNAN R 👋")
                        .font(.headline)
                        .fontWeight(.bold)
                    Text("Here&#39s what&#39s happening with your projects today 👇")
                        .font(.caption)
                }
                Spacer()
                VStack{
                    VStack(alignment: .leading){
                        HStack (alignment: .top) {
                            HStack(alignment: .center){
//                                AsyncImage(url: URL(string: "https://yt3.ggpht.com/T9IuKawbxOW0FXuRNNUbQaZPC7VuNu-GXW4lDLCW6-kKqFaCQViXgVUpB_fzaslXU-c1W3W-=s800-c-k-c0x00ffffff-no-rj")) { phase in
//                                    switch phase {
//                                    case .success(let image):
//                                        image
//                                            .resizable()
//                                            .aspectRatio(contentMode: .fit)
//                                            .frame(width: 190, height: 190)
//                                            .clipShape(Circle())
//                                    case .failure(let error):
//                                        // Handle image loading failure
//                                        Text("Failed to load image: \(error.localizedDescription)")
//                                            .foregroundColor(.red)
//                                        
//                                    case .empty:
//                                        ProgressView()
//                                    @unknown default:
//                                        EmptyView()
//                                    }
//                                }
                                
                                
                                
                        
                            
                            Text("\(websocket.messages.first?.user.first?.count ?? "channel Name")")
                                .font(.system(size: 39))
                                .fontWeight(.bold)
                            }
                        }
                        
                        HStack {
                            Text("\(self.websocket.messages.first?.counts.first?.count ?? 0)")
                                               .font(.title)
                                               .fontWeight(.bold)
                                               .foregroundStyle(.red)
                        }
                        
                        Text("Total Subscribers")
                            .font(.system(size: 24))
                    }
                    .onAppear{

                        self.websocket.objectWillChange.send()
                    }
                    .padding()
                    
                    
                }
               
            }
            SubChart()
            if let videos = self.videofetcher.videos {
                if videos.videos.isEmpty {
                    Text("No videos available")
                } else {
                    // Determine number of columns based on platform
                    let numberOfColumns = false ? 3 : 1

                    // Use LazyVGrid for grid layout
                    LazyVGrid(columns: Array(repeating: GridItem(), count: numberOfColumns), spacing: 10) {
                        ForEach(videos.videos, id: \.self.videoID) { video in
                            Button(action: {
                                selectedVideo = video
                                showActivity = true
                            }) {
                                VideoSection(video: video)
                            }
                            .onAppear {
                                selectedVideo = video
                            }
                            .sheet(isPresented: $showActivity) {
                                if let selectedVideo = selectedVideo {
                                    NavigationView {
                                        NextVideoView(video: selectedVideo)
                                    }
                                } else {
                                    Text("No video selected")
                                }
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }
            } else {
                // Display a placeholder or loading indicator
                Text("Loading...")
            }

        }
        .onAppear{
            self.videofetcher.fetchVideo()
        }
    }
}

#Preview {
    LandingTvosView()
}
