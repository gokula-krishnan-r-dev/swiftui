//
//  AnalysisT.swift
//  autocommentIq Watch App
//
//  Created by Gokula Krishnan R on 01/04/24.
//



import Foundation

struct AnalysisT: Codable {
    let values: AnalysisTValues
}

struct AnalysisTValues: Codable {
    let subscribersGained: [AnalysisTSubscribersGained]
    let subscribersGained_total_count: Int
    let subscribersGained_percentageChange: Float
    let views: [AnalysisTView]
    let views_total_count: Int
    let views_percentageChange: Float
    let likes: [AnalysisTLike]
    let likes_total_count: Int
    let likes_percentageChange: Float
    let comments: [AnalysisTCommentElement]
    let comments_total_count: Int
    let comments_percentageChange: Float
    let estimatedMinutesWatched: [AnalysisTEstimatedMinutesWatched]
    let estimatedMinutesWatched_total_count: Int
    let estimatedMinutesWatched_percentageChange: Float
    let averageViewDuration: [AnalysisTAverageViewDuration]
    let averageViewDuration_total_count: Int
    let averageViewDuration_percentageChange: Float
    let shares: [AnalysisTShare]
    let shares_total_count: Int
    let shares_percentageChange: Float
    let dislikes: [AnalysisTDislike]
    let dislikes_total_count: Int
    let dislikes_percentageChange: Float
    let annotationClickThroughRate: [AnalysisTAnnotationClickThroughRate]
    let annotationClickThroughRate_total_count: Int
    let annotationClickThroughRate_percentageChange: Float
    let annotationCloseRate: [AnalysisTAnnotationCloseRate]
    let annotationCloseRate_total_count: Int
    let annotationCloseRate_percentageChange: Float
    let annotationImpressions: [AnalysisTAnnotationImpression]
    let annotationImpressions_total_count: Int
    let annotationImpressions_percentageChange: Float
    let viewsPerPlaylistStart: [AnalysisTViewsPerPlaylistStart]
    let viewsPerPlaylistStart_total_count: Int
    let viewsPerPlaylistStart_percentageChange: Float
    let averageTimeInPlaylist: [AnalysisTAverageTimeInPlaylist]
    let averageTimeInPlaylist_total_count: Int
    let averageTimeInPlaylist_percentageChange: Float
}

struct AnalysisTSubscribersGained: Codable , Identifiable{
    var id: Float?
    let date: String
    let subscribersGained: Int
}

struct AnalysisTView: Codable , Identifiable {
    var id: Float?
    let date: String
    let views: Int
}

struct AnalysisTLike: Codable , Identifiable {
    var id: Float?
    let date: String
    let likes: Int
}

struct AnalysisTCommentElement: Codable ,Identifiable  {
    var id: Float?
    let date: String
    let comments: Int
}

struct AnalysisTEstimatedMinutesWatched: Codable , Identifiable {
    var id: Float?
    let date: String
    let estimatedMinutesWatched: Int
}

struct AnalysisTAverageViewDuration: Codable , Identifiable {
    var id: Float?
    let date: String
    let averageViewDuration: Int
}

struct AnalysisTShare: Codable , Identifiable {
    var id: Float?
    let date: String
    let shares: Int
}

struct AnalysisTDislike: Codable , Identifiable {
    var id: Float?
    let date: String
    let dislikes: Int
}

struct AnalysisTAnnotationClickThroughRate: Codable , Identifiable {
    var id: Float?
    let date: String
    let annotationClickThroughRate: Int
}

struct AnalysisTAnnotationCloseRate: Codable , Identifiable {
    var id: Float?
    let date: String
    let annotationCloseRate: Int
}

struct AnalysisTAnnotationImpression: Codable  , Identifiable{
    var id: Float?
    let date: String
    let annotationImpressions: Int
}

struct AnalysisTViewsPerPlaylistStart: Codable , Identifiable {
    var id: Float?
    let date: String
    let viewsPerPlaylistStart: Int
}

struct AnalysisTAverageTimeInPlaylist: Codable , Identifiable {
    var id: Float?
    let date: String
    let averageTimeInPlaylist: Int
}
