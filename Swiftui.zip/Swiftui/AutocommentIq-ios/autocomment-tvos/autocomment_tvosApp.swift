//
//  autocomment_tvosApp.swift
//  autocomment-tvos
//
//  Created by Gokula Krishnan R on 02/04/24.
//

import SwiftUI

@main
struct autocomment_tvosApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
