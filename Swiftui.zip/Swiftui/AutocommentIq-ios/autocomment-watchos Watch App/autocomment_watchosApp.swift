//
//  autocomment_watchosApp.swift
//  autocomment-watchos Watch App
//
//  Created by Gokula Krishnan R on 02/04/24.
//

import SwiftUI

@main
struct autocommentwatchosWatchAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
