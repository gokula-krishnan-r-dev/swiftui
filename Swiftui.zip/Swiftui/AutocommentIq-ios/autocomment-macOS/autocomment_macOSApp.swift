//
//  autocomment_macOSApp.swift
//  autocomment-macOS
//
//  Created by Gokula Krishnan R on 02/04/24.
//

import SwiftUI

@main
struct autocomment_macOSApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
