//
//  ContentView.swift
//  autocomment-macOS
//
//  Created by Gokula Krishnan R on 02/04/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
     autocommentView()
    }
}

#Preview {
    ContentView()
}
