//
//  autocommentIq_tvApp.swift
//  autocommentIq-tv
//
//  Created by Gokula Krishnan R on 02/04/24.
//

import SwiftUI

@main
struct autocommentIq_tvApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
